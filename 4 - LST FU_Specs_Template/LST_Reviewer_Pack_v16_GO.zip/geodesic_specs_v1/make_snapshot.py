#!/usr/bin/env python3
import os, json, argparse

KEY_FILES = [
  "CERT_summary.csv","validation_report.json","GO_NOGO.txt","MERKLE_ROOT.txt",
  "A_U1_selection/SNF_REPORT.json",
  "B_Deff_uniqueness/Deff_interval_proof.json",
  "C_projector_uniqueness/proj_metrics_v2.json",
  "D_su4_no_go/SYL_cert.json","D_su4_no_go/GERSH_cert.json","D_su4_no_go/minimal_witness.json",
  "E_no_singularity/nosing_metrics_v2.json"
]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='SNAPSHOT.json')
    args = ap.parse_args()
    snap = {"files":{}}
    for p in KEY_FILES:
        if os.path.exists(p):
            snap["files"][p] = {"size": os.path.getsize(p)}
    with open(args.out,'w',encoding='utf-8') as f:
        json.dump(snap,f,indent=2)
    print(json.dumps({"tracked": len(snap["files"])}))
if __name__ == "__main__":
    main()
