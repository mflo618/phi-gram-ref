#!/usr/bin/env python3
import os, json, csv, importlib, argparse

def dump_csv_matrix(path, A):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f); w.writerows(A)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='integrations.json')
    ap.add_argument('--outdir', default='inputs')
    ap.add_argument('--demo-if-missing', action='store_true', help='Emit demo inputs if imports fail')
    args = ap.parse_args()
    with open(args.config, 'r', encoding='utf-8') as f:
        cfg = json.load(f)
    results = []
    def try_call(key, target_path):
        item = cfg.get(key, {})
        mod = item.get('module'); fn = item.get('function'); kwargs = item.get('kwargs', {})
        try:
            m = importlib.import_module(mod)
            f = getattr(m, fn)
            data = f(**kwargs)
            # persist to target_path(s)
            if key == 'horizon_exporter':
                # expects list[list[number]] -> horizon_P3.csv
                dump_csv_matrix(os.path.join(args.outdir, 'horizon_P3.csv'), data)
                results.append({key: 'ok', 'path': os.path.join(args.outdir, 'horizon_P3.csv')})
            elif key == 'sigma2_exporter':
                dump_csv_matrix(os.path.join(args.outdir, 'sigma_second_variation.csv'), data)
                results.append({key: 'ok', 'path': os.path.join(args.outdir, 'sigma_second_variation.csv')})
            elif key == 'su4_hessian_exporter':
                folder = os.path.join(args.outdir, 'su4_hessian'); os.makedirs(folder, exist_ok=True)
                for i, H in enumerate(data, 1):
                    dump_csv_matrix(os.path.join(folder, f'H_{i:03d}.csv'), H)
                results.append({key: 'ok', 'count': len(data), 'folder': folder})
        except Exception as e:
            if args.demo_if_missing:
                # Produce demo data
                if key == 'horizon_exporter':
                    demo = [[1 if c==r else 0 for c in range(12)] for r in range(11)]
                    dump_csv_matrix(os.path.join(args.outdir, 'horizon_P3.csv'), demo)
                    results.append({key: 'demo', 'path': os.path.join(args.outdir, 'horizon_P3.csv'), 'error': str(e)})
                elif key == 'sigma2_exporter':
                    demo = [[2.0, 0.3, 0.1],[0.3, 1.5, 0.2],[0.1,0.2,1.2]]
                    dump_csv_matrix(os.path.join(args.outdir, 'sigma_second_variation.csv'), demo)
                    results.append({key: 'demo', 'path': os.path.join(args.outdir, 'sigma_second_variation.csv'), 'error': str(e)})
                elif key == 'su4_hessian_exporter':
                    folder = os.path.join(args.outdir, 'su4_hessian'); os.makedirs(folder, exist_ok=True)
                    demo = [
                        [[2.0,-0.00012,0.0],[-0.00012,1.6,0.0],[0.0,0.0,1.2]],
                        [[2.0,-0.00015,0.0],[-0.00015,1.6,0.0],[0.0,0.0,1.2]],
                    ]
                    for i, H in enumerate(demo, 1):
                        dump_csv_matrix(os.path.join(folder, f'H_{i:03d}.csv'), H)
                    results.append({key: 'demo', 'count': len(demo), 'folder': folder, 'error': str(e)})
            else:
                results.append({key: 'error', 'reason': str(e)})
    try_call('horizon_exporter', 'horizon_P3.csv')
    try_call('sigma2_exporter', 'sigma_second_variation.csv')
    try_call('su4_hessian_exporter', 'su4_hessian/*.csv')
    print(json.dumps({'integrations': results}, indent=2))

if __name__ == '__main__':
    main()
