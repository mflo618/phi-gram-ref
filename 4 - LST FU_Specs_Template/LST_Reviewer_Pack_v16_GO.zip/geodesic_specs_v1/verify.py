#!/usr/bin/env python3
import csv, json, pathlib
BASE = pathlib.Path(__file__).resolve().parent
rows = list(csv.DictReader(open(BASE/"CERT_summary.csv", encoding="utf-8")))
validation = json.load(open(BASE/"validation_report.json")) if (BASE/"validation_report.json").exists() else {"ok": True}
go = (BASE/"GO_NOGO.txt").read_text().strip() if (BASE/"GO_NOGO.txt").exists() else "UNKNOWN"
print("\nLST Certificates — quick status")
for r in rows:
    print(f" - {r['claim']}: {'PASS' if r['pass'].lower()=='true' else 'FAIL'}  |  {r['reason']}")
print(f"\nSchema validation: {'OK' if validation.get('ok',True) else 'FAIL'}")
print(f"GO / NOGO: {go}\n")
