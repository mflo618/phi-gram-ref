#!/usr/bin/env python3
import os, json, argparse, csv

def det2(a,b,c,d): return a*d - b*c
def det3(A):
    a,b,c = A[0]; d,e,f = A[1]; g,h,i = A[2]
    return a*(e*i - f*h) - b*(d*i - f*g) + c*(d*h - e*g)

def one_negative(A, eps=0.0):
    d1 = A[0][0]
    d2 = det2(A[0][0], A[0][1], A[1][0], A[1][1])
    d3 = det3(A)
    def s(x): 
        if x > eps: return 1
        if x < -eps: return -1
        return 0
    seq = [1, s(d1), s(d2), s(d3)]
    if 0 in seq: 
        return False
    changes = sum(1 for a,b in zip(seq, seq[1:]) if a*b < 0)
    return changes == 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--inputs', default='D_su4_no_go/hessian_inputs.json')
    ap.add_argument('--fallback', default='D_su4_no_go/hessian_traces_v2.csv')
    ap.add_argument('--out', default='D_su4_no_go/minimal_witness.json')
    args = ap.parse_args()
    mats = []
    if os.path.exists(args.inputs):
        with open(args.inputs,'r',encoding='utf-8') as f:
            mats = [x["H"] for x in json.load(f).get("hessians",[])]
    if not mats and os.path.exists(args.fallback):
        rows=[]
        with open(args.fallback,'r',encoding='utf-8') as f:
            for i,row in enumerate(csv.reader(f)):
                if i==0: continue
                tau, lam_min, lam_p1, lam_p2, _ = map(float,row)
                mats.append([[lam_min,0,0],[0,lam_p1,0],[0,0,lam_p2]])
    witness = None
    for idx, A in enumerate(mats,1):
        if one_negative(A):
            witness = {"idx": idx, "A": A}; break
    out = {"found": witness is not None, "witness": witness}
    with open(args.out,'w',encoding='utf-8') as f:
        json.dump(out,f,indent=2)
    print(json.dumps(out))
if __name__ == '__main__':
    main()
