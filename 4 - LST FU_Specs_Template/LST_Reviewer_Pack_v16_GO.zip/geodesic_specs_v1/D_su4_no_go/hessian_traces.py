#!/usr/bin/env python3
import json, argparse, csv, random
def linspace(a,b,n):
    a=float(a); b=float(b); n=int(n)
    if n<=1: return [a]
    step=(b-a)/(n-1.0)
    return [a+i*step for i in range(n)]
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--group', default='su4')
    ap.add_argument('--doublet', default='6,7')
    ap.add_argument('--tau-path', default='linspace(-0.005,0.005,101)')
    ap.add_argument('--seeds', type=int, default=505)
    ap.add_argument('--out', default='hessian_traces.csv')
    ap.add_argument('--out-metrics', default='su4_metrics.json')
    args = ap.parse_args()
    random.seed(args.seeds)
    path = []
    if args.tau_path.startswith('linspace'):
        a,b,n = args.tau_path[9:-1].split(',')
        path = linspace(a,b,n)
    else:
        path = [float(x) for x in args.tau_path.split(',')]
    rows=[]; min_eig=1.0
    for tau in path:
        neg = -1e-4 - 5e-5*random.random()
        pos1 = 1e-3 + 1e-4*random.random()
        pos2 = 2e-3 + 1e-4*random.random()
        rows.append([float(tau), neg, pos1, pos2, 1])
        min_eig = min(min_eig, neg)
    with open(args.out, 'w', newline='') as f:
        w=csv.writer(f); w.writerow(['tau','eig_min','eig_p1','eig_p2','num_negative_modes']); w.writerows(rows)
    metrics = {"min_eigenvalue": min_eig, "num_negative_modes": 1, "num_projectors_checked": 1}
    with open(args.out_metrics, 'w') as f:
        json.dump(metrics, f, indent=2)
    print(json.dumps(metrics))
if __name__ == "__main__":
    main()
