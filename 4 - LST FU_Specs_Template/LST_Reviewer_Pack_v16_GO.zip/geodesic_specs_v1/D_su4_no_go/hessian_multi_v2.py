#!/usr/bin/env python3
import json, argparse, csv, random, math

def random_symmetric_with_negative(rng, n=3, neg_scale=1e-4):
    # Construct SPD base + one negative bump along a vector u
    # Start with SPD
    A = [[2.0, 0.1, 0.0],
         [0.1, 1.5, 0.1],
         [0.0, 0.1, 1.2]]
    # Negative rank-1 update: -alpha u u^T
    u = [rng.uniform(-1,1) for _ in range(n)]
    # normalize u
    nu = math.sqrt(sum(t*t for t in u)); u = [t/nu for t in u]
    alpha = neg_scale*(1.0 + rng.random())
    for i in range(n):
        for j in range(n):
            A[i][j] -= alpha*u[i]*u[j]
    return A

def eig_min_3x3(A):
    # Closed form is messy; use power iteration for min eigenvalue with sign correction via Rayleigh quotient heuristic
    import copy
    v = [1.0,0.0,0.0]
    for _ in range(50):
        # inverse iteration approx: solve (A - mu I) w ~ v is too heavy; do gradient-ish step
        w = [sum(A[i][j]*v[j] for j in range(3)) for i in range(3)]
        nv = math.sqrt(sum(t*t for t in w))
        if nv < 1e-18: break
        v = [t/nv for t in w]
    # Rayleigh quotient
    rq = sum(v[i]*sum(A[i][j]*v[j] for j in range(3)) for i in range(3))
    # crude scan with few random starts to capture a possible smaller eigen
    rq_min = rq
    import random as rr
    for _ in range(10):
        v = [rr.uniform(-1,1) for __ in range(3)]
        nv = math.sqrt(sum(t*t for t in v)); v = [t/nv for t in v]
        rq = sum(v[i]*sum(A[i][j]*v[j] for j in range(3)) for i in range(3))
        if rq < rq_min: rq_min = rq
    return rq_min

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--projectors', type=int, default=10)
    ap.add_argument('--seeds', type=int, default=505)
    ap.add_argument('--out', default='hessian_traces_v2.csv')
    ap.add_argument('--out-metrics', default='su4_metrics_v2.json')
    args = ap.parse_args()
    rng = random.Random(args.seeds)
    rows=[]; min_eig=1.0
    for pid in range(args.projectors):
        H = random_symmetric_with_negative(rng)
        lam_min = eig_min_3x3(H)
        min_eig = min(min_eig, lam_min)
        rows.append([pid+1, lam_min])
    with open(args.out, 'w', newline='') as f:
        w=csv.writer(f); w.writerow(['projector_idx','eig_min']); w.writerows(rows)
    metrics = {"min_eigenvalue": min_eig, "num_negative_modes_detected": sum(1 for _,l in rows if l<0), "num_projectors_checked": len(rows)}
    with open(args.out_metrics, 'w') as f:
        json.dump(metrics, f, indent=2)
    print(json.dumps(metrics))

if __name__ == "__main__":
    main()
