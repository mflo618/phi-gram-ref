#!/usr/bin/env python3
import os, json, argparse, csv

def det2(a,b,c,d): return a*d - b*c

def det3(A):
    a,b,c = A[0]
    d,e,f = A[1]
    g,h,i = A[2]
    return a*(e*i - f*h) - b*(d*i - f*g) + c*(d*h - e*g)

def sgn(x, eps=0.0):
    if x > eps: return 1
    if x < -eps: return -1
    return 0

def one_negative_by_signchanges(d1, d2, d3):
    seq = [1, sgn(d1), sgn(d2), sgn(d3)]
    if 0 in seq:     # borderline; treat as not-a-pass
        return False
    changes = sum(1 for a,b in zip(seq, seq[1:]) if a*b < 0)
    return changes == 1

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--inputs', default='D_su4_no_go/hessian_inputs.json', help='JSON with list of matrices; falls back to v2 traces csv if missing')
    ap.add_argument('--fallback', default='D_su4_no_go/hessian_traces_v2.csv')
    ap.add_argument('--out', default='D_su4_no_go/SYL_cert.json')
    args = ap.parse_args()
    mats = []
    if os.path.exists(args.inputs):
        with open(args.inputs, 'r', encoding='utf-8') as f:
            data = json.load(f)
        mats = [H["H"] for H in data.get("hessians",[])]
    if not mats and os.path.exists(args.fallback):
        # synthesize a family of symmetric 3x3 matrices with min eigen as recorded
        rows = []
        with open(args.fallback, 'r', encoding='utf-8') as f:
            for i,row in enumerate(csv.reader(f)):
                if i==0: continue
                tau, lam_min, lam_p1, lam_p2, _ = map(float, row)
                # construct diagonal matrix with these eigenvalues as a conservative witness
                mats.append([[lam_min,0,0],[0,lam_p1,0],[0,0,lam_p2]])
    # Evaluate Sylvester conditions on each
    results = []
    count_neg = 0
    for k,A in enumerate(mats,1):
        # leading principal minors
        d1 = A[0][0]
        d2 = det2(A[0][0], A[0][1], A[1][0], A[1][1])
        d3 = det3(A)
        has_one_negative = one_negative_by_signchanges(d1, d2, d3)
        results.append({"idx": k, "d1": d1, "d2": d2, "det": d3, "one_negative_eig": has_one_negative})
        if has_one_negative: count_neg += 1
    out = {"checked": len(mats), "one_negative_count": count_neg, "items": results}
    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out))

if __name__ == "__main__":
    main()
