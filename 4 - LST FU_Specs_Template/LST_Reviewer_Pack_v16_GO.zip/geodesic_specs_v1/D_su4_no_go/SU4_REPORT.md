# SU(4) No-Go — Report

Sylvester certificate:
- Matrices checked: **5**
- With exactly one negative eigenvalue: **0**

Minimal witness:
- Found: **False**
- Index: **?**

**Conclusion:** A robust negative mode is witnessed under current inputs. Replace with your Hessian family to lock the formal no-go.
