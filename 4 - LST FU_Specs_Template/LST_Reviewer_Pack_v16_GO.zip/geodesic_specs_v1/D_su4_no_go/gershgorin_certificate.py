#!/usr/bin/env python3
import os, json, argparse, csv

def gershgorin_intervals(A):
    itv = []
    for i in range(len(A)):
        c = A[i][i]
        r = sum(abs(A[i][j]) for j in range(len(A)) if j!=i)
        itv.append([c - r, c + r])
    return itv

def has_negative_interval(itv):
    return any(lo < 0 for lo,hi in itv)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--inputs', default='D_su4_no_go/hessian_inputs.json')
    ap.add_argument('--fallback', default='D_su4_no_go/hessian_traces_v2.csv')
    ap.add_argument('--out', default='D_su4_no_go/GERSH_cert.json')
    args = ap.parse_args()
    mats = []
    if os.path.exists(args.inputs):
        with open(args.inputs,'r',encoding='utf-8') as f:
            data = json.load(f)
        mats = [x["H"] for x in data.get("hessians",[])]
    if not mats and os.path.exists(args.fallback):
        with open(args.fallback,'r',encoding='utf-8') as f:
            for i,row in enumerate(csv.reader(f)):
                if i==0: continue
                _, lmin, lp1, lp2, _ = map(float,row)
                mats.append([[lmin,0,0],[0,lp1,0],[0,0,lp2]])
    results=[]; count=0
    for k,A in enumerate(mats,1):
        itv = gershgorin_intervals(A)
        neg = has_negative_interval(itv)
        results.append({"idx": k, "intervals": itv, "has_negative": neg})
        if neg: count+=1
    out={"checked": len(mats), "has_negative_count": count, "items": results}
    with open(args.out,'w',encoding='utf-8') as f:
        json.dump(out,f,indent=2)
    print(json.dumps(out))

if __name__ == "__main__":
    main()
