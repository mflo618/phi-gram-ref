#!/usr/bin/env python3
import os, json, argparse, glob

def scan_cert(path):
    try:
        with open(path,'r',encoding='utf-8') as f:
            j = json.load(f)
        inv = j.get("invariants", {})
        return {
            "has_six_over_five": ("six_over_five" in inv) or ("6/5" in json.dumps(inv)),
            "has_phi": ("phi" in inv) or ("golden" in json.dumps(inv).lower()),
            "has_h": ("h" in inv),
            "has_kappa": ("kappa" in inv) or ("κ" in json.dumps(inv)),
        }
    except Exception:
        return {"error": True}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--glob', default='**/CERT*_v*.json')
    ap.add_argument('--out', default='INVARIANT_AUDIT.json')
    args = ap.parse_args()
    files = []
    for base,_,fs in os.walk('.'):
        for f in fs:
            if f.startswith('CERT') and f.endswith('.json'):
                files.append(os.path.join(base,f))
    rep = {}
    for p in sorted(files):
        rep[p] = scan_cert(p)
    with open(args.out,'w',encoding='utf-8') as f:
        json.dump(rep,f,indent=2)
    print(json.dumps({"count": len(rep)}))
if __name__ == "__main__":
    main()
