# LST — Non‑Empirical Geodesic Spec Pack v4 (Self‑Contained)

**What’s new here vs v3**
- All five **certificate schemas** are included in each folder.
- **Data adapters** let you feed real inputs (horizon P3 constraints, Σ″ baseline, SU(4) Hessians).
- A one‑shot **`run_all.py`** executes adapters → checks → summary → validation and writes `RUN_REPORT.json`.

## Optional Inputs (drop these paths if you have them)
- `inputs/horizon_P3.csv` → builds `A_U1_selection/constraints.json`
- `inputs/sigma_second_variation.csv` → sets `C_projector_uniqueness/S_baseline.json`
- `inputs/su4_hessian/*.csv` → aggregates to `D_su4_no_go/hessian_inputs.json`

## One‑liner
```
python run_all.py
cat RUN_REPORT.json
cat CERT_summary.csv
cat validation_report.json
```

Generated: 2025-10-27 15:04:10Z UTC
