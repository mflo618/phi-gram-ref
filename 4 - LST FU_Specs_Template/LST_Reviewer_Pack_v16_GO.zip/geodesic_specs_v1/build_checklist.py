#!/usr/bin/env python3
import os, json, csv, argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--summary', default='CERT_summary.csv')
    ap.add_argument('--go', default='GO_NOGO.txt')
    ap.add_argument('--out', default='SUFFICIENCY_CHECKLIST.json')
    args = ap.parse_args()
    items = []
    if os.path.exists(args.summary):
        with open(args.summary,'r',encoding='utf-8') as f:
            for i,row in enumerate(csv.reader(f)):
                if i==0: continue
                if not row: continue
                items.append({"claim_id": row[0], "version": row[1], "pass": row[2]=="True", "reason": row[3], "path": row[4]})
    go = "UNKNOWN"
    if os.path.exists(args.go):
        with open(args.go,'r',encoding='utf-8') as f:
            go = f.readline().strip()
    out = {"GO_NOGO": go, "claims": items}
    with open(args.out,'w',encoding='utf-8') as f:
        json.dump(out,f,indent=2)
    print(json.dumps(out))

if __name__ == '__main__':
    main()
