#!/usr/bin/env python3
import os, json, subprocess, sys, argparse, time

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--group', default='su4', choices=['su3','su4'])
    ap.add_argument('--grid', default='14')
    ap.add_argument('--B', default='512')
    ap.add_argument('--refine', default='1')
    ap.add_argument('--out', default='external/phi_gram_summary.json')
    ap.add_argument('--script', default='external/phi_gram_ref.py')
    args = ap.parse_args()
    cmd = [sys.executable, args.script,
           '--group', args.group, '--grid', str(args.grid),
           '--B', str(args.B), '--refine', str(args.refine)]
    ok = False; out = ""; err = ""
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True, cwd=os.path.dirname(__file__) or ".")
        ok = True
    except Exception as e:
        err = str(e)
    # If the ref script produced a summary, keep it; otherwise create a stub
    summary_path = os.path.join(os.path.dirname(__file__) or ".", "external", "phi_gram_summary.json")
    if not os.path.exists(summary_path):
        # Create a conservative stub summary
        stub = {
            "status": "stub",
            "reason": "phi_gram_ref.py not executed; dependencies likely missing",
            "group": args.group,
            "grid": int(args.grid), "B": int(args.B), "refine": int(args.refine),
            "lambda_min": 0.0, "lambda_max": 1.0, "cond": 1.0,
            "spectral_radius": 0.0, "delta_p2n": 0.0,
            "ok": False
        }
        with open(summary_path, "w", encoding="utf-8") as f:
            json.dump(stub, f, indent=2)
        print(json.dumps({"created_stub": True, "path": summary_path}))
    else:
        print(json.dumps({"used_summary": True, "path": summary_path}))

if __name__ == '__main__':
    main()
