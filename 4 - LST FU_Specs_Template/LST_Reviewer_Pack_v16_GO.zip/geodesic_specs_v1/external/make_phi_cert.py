#!/usr/bin/env python3
import os, json, hashlib, datetime

ROOT = os.path.dirname(__file__) or "."

def sha256(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    summ_path = os.path.join(ROOT, "phi_gram_summary.json")
    if not os.path.exists(summ_path):
        raise SystemExit("missing phi_gram_summary.json")
    with open(summ_path, 'r', encoding='utf-8') as f:
        s = json.load(f)
    metrics = {
        "lambda_min": float(s.get("lambda_min", 0.0)),
        "lambda_max": float(s.get("lambda_max", 1.0)),
        "cond": float(s.get("cond", 1.0)),
        "spectral_radius": float(s.get("spectral_radius", 0.0)),
        "delta_p2n": float(s.get("delta_p2n", 0.0)),
        "grid": float(s.get("grid", 0)),
        "B": float(s.get("B", 0)),
    }
    # pass criterion: summary ok flag present or stub treated as non-pass
    ok = bool(s.get("ok", False))
    cert = {
        "claim_id": "C-PhiGram",
        "version": "v2",
        "generated_at_utc": datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "inputs": {"summary_path": "external/phi_gram_summary.json"},
        "invariants": {"phi": True, "six_over_five": True},
        "random_seeds": {"main": 42},
        "tolerances": {"cond_max_warn": 1e8},
        "computations": ["phi_gram_ref: Gram PSD eigen analysis, Cesàro projector stats"],
        "metrics": metrics,
        "result": {"pass": ok, "reason": "summary.ok==True" if ok else "summary.ok!=True (stub or non-ok)"},
        "provenance": {"summary_sha256": sha256(summ_path)}
    }
    out = os.path.join(ROOT, "CERT_phigram_v2.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(cert, f, indent=2)
    print(json.dumps({"wrote": out, "pass": ok, "grid": metrics["grid"], "B": metrics["B"]}))

if __name__ == "__main__":
    main()
