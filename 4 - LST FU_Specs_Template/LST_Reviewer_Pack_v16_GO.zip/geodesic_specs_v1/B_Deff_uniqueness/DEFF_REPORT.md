# D_eff — Proof-Style Certificate

Interval proof (outward rounding):
- φ in **[?, ?]**
- c = √(6/5) in **[?, ?]**
- **D_eff** in **[?, ?]** (width = ?)

Uniqueness:
- F′(D) = −ln φ < 0 → monotone
- Contraction map T(D) is **constant** → Lipschitz **L = 0** → unique fixed point.

Numerical enclosure (v2): [2.810499978683637, 2.8106199786836368], L = 0.0.
