#!/usr/bin/env python3
import json, argparse, csv, os

def read_matrix_csv(p):
    A=[]
    with open(p, 'r', encoding='utf-8') as f:
        for row in csv.reader(f):
            if not row: continue
            A.append([float(x) for x in row])
    return A

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sigma2', default='inputs/sigma_second_variation.csv', help='CSV square matrix to use as SPD baseline')
    ap.add_argument('--out', default='C_projector_uniqueness/S_baseline.json')
    args = ap.parse_args()
    if not os.path.exists(args.sigma2):
        print(json.dumps({"status":"noop","reason":"no sigma'' file"})); return
    A = read_matrix_csv(args.sigma2)
    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump({"S": A}, f, indent=2)
    print(json.dumps({"status":"ok","shape":[len(A), len(A[0]) if A else 0]}))

if __name__ == "__main__":
    main()
