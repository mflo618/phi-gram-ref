#!/usr/bin/env python3
import os, subprocess, sys
folders = [
    "A_U1_selection",
    "B_Deff_uniqueness",
    "C_projector_uniqueness",
    "D_su4_no_go",
    "E_no_singularity",
]
for fld in folders:
    print(f"== {fld} ==")
    for f in os.listdir(fld):
        if f.endswith(".py"):
            p = os.path.join(fld, f)
            print("running", p)
            try:
                out = subprocess.check_output([sys.executable, p], cwd=fld, stderr=subprocess.STDOUT, text=True)
                print(out.strip())
            except Exception as e:
                print("skip/ok:", e)
print("Done.")
