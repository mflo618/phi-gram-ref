#!/usr/bin/env python3
import subprocess, sys, json, os

def run(cmd, cwd):
    try:
        out = subprocess.check_output(cmd, cwd=cwd, stderr=subprocess.STDOUT, text=True)
        return True, out.strip()
    except subprocess.CalledProcessError as e:
        return False, e.output

def main():
    base = os.path.dirname(__file__) or "."
    steps = []
    for cmd in [
        ["python","run_all.py"],
        ["python","sufficient_check.py"],
        ["python","generate_dashboard.py"],
        ["python","score_completeness.py"],
        ["python","audit_invariants.py"],
        ["python","make_snapshot.py"],
        ["python","diff_snapshot.py","--old","SNAPSHOT.json","--new","SNAPSHOT.json","--out","DELTA_REPORT.json"]
    ]:
        ok, out = run(cmd, base)
        steps.append({"cmd":" ".join(cmd), "ok": ok, "out": out})
    with open(os.path.join(base,"ORCHESTRATION_REPORT.json"),"w",encoding="utf-8") as f:
        json.dump({"steps": steps}, f, indent=2)
    print(json.dumps({"done": True, "steps": len(steps)}))

if __name__ == "__main__":
    main()
