# Projector Uniqueness — Report

Statistics over projectors:
- Count: **20**
- C_sigma mean: **1.590114**
- C_sigma std: **0.148305**
- Range: **[1.320136, 1.791861]**

**Conclusion:** Variation small and signatures stable under the current baseline. Swap in Σ″(τ=0) from your GGF exporter to finalize.
