#!/usr/bin/env python3
import json, argparse, csv, random, math

def matmul(A,B):
    return [[sum(A[i][k]*B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]

def transp(A):
    return [list(row) for row in zip(*A)]

def dot(x,y): return sum(a*b for a,b in zip(x,y))

def quad_form(A,x):
    # x^T A x
    return sum(x[i]*sum(A[i][j]*x[j] for j in range(len(A))) for i in range(len(A)))

def normalize(v):
    n = math.sqrt(sum(t*t for t in v)); 
    return [t/n for t in v]

def random_orthonormal(n, rng):
    # simple Gram-Schmidt from random vectors
    vecs = []
    for _ in range(n):
        v = [rng.uniform(-1,1) for __ in range(n)]
        for u in vecs:
            proj = dot(v,u)
            v = [vi - proj*ui for vi,ui in zip(v,u)]
        v = normalize(v)
        vecs.append(v)
    return transp(vecs)  # columns are orthonormal

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--n', type=int, default=3)
    ap.add_argument('--num-projectors', type=int, default=20)
    ap.add_argument('--seeds', type=int, default=404)
    ap.add_argument('--out', default='projector_sweep_v2.csv')
    ap.add_argument('--out-metrics', default='proj_metrics_v2.json')
    args = ap.parse_args()
    rng = random.Random(args.seeds)
    # SPD base matrix S (acts like Σ'' baseline)
    S = [[2.0, 0.3, 0.1],
         [0.3, 1.5, 0.2],
         [0.1, 0.2, 1.2]]
    # Define curvature scalar C_sigma as normalized average of quad form on unit vectors projected by P
    rows = []; Cs = []
    for pid in range(args.num_projectors):
        Q = random_orthonormal(args.n, rng)
        # rank-2 projector as an example: P = Q diag(1,1,0) Q^T
        D = [[1,0,0],[0,1,0],[0,0,0]]
        # P = Q D Q^T
        Qt = transp(Q)
        P = matmul(matmul(Q,D), Qt)
        # sample unit vectors e1,e2,e3 standard basis, project, then evaluate quad on S
        C_vals = []
        for e in [[1,0,0],[0,1,0],[0,0,1]]:
            # v = P e
            v = [sum(P[i][j]*e[j] for j in range(3)) for i in range(3)]
            n = math.sqrt(sum(t*t for t in v))
            if n < 1e-12:
                continue
            v = [t/n for t in v]
            C_vals.append(quad_form(S, v))
        Csig = sum(C_vals)/len(C_vals)
        rows.append([pid+1, "proj_%d" % (pid+1), round(Csig,8)])
        Cs.append(Csig)
    mu = sum(Cs)/len(Cs)
    std = (sum((c-mu)**2 for c in Cs)/len(Cs))**0.5
    with open(args.out, 'w', newline='') as f:
        w = csv.writer(f); w.writerow(['idx','projector_id','C_sigma']); w.writerows(rows)
    metrics = {"num_projectors": len(rows), "C_sigma_mean": mu, "C_sigma_std": std, "C_sigma_min": min(Cs), "C_sigma_max": max(Cs)}
    with open(args.out_metrics, 'w') as f:
        json.dump(metrics, f, indent=2)
    print(json.dumps(metrics))

if __name__ == "__main__":
    main()
