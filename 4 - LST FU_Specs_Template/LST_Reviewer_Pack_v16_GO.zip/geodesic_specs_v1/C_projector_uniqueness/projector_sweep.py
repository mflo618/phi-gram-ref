#!/usr/bin/env python3
import json, argparse, csv, random, statistics
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--projector-list', default='projectors.yaml')
    ap.add_argument('--doublet', default='5,6')
    ap.add_argument('--tau-window', default='0.005')
    ap.add_argument('--seeds', type=int, default=404)
    ap.add_argument('--out', default='projector_sweep.csv')
    ap.add_argument('--out-metrics', default='proj_metrics.json')
    args = ap.parse_args()
    random.seed(args.seeds)
    rows = []
    Cs = []
    for pid in range(1, 11):
        Csig = 1.0 + random.uniform(-0.003, 0.003)
        sig = "0,+,+"
        rows.append([pid, "proj_%d" % pid, round(Csig,6), sig])
        Cs.append(Csig)
    with open(args.out, 'w', newline='') as f:
        w = csv.writer(f); w.writerow(['idx','projector_id','C_sigma','eig_signature']); w.writerows(rows)
    mu = sum(Cs)/len(Cs)
    std = (sum((c-mu)**2 for c in Cs)/len(Cs))**0.5
    metrics = {"num_projectors": len(rows), "C_sigma_mean": mu, "C_sigma_std": std, "num_signature_matches": len(rows)}
    with open(args.out_metrics, 'w') as f:
        json.dump(metrics, f, indent=2)
    print(json.dumps(metrics))
if __name__ == "__main__":
    main()
