# HOWTO — Finalize Physics‑Backed Certificates

1) Edit `integrations.json` to reference your real exporters:
   - `your_repo.horizon.extractor.export_horizon_constraints`
   - `your_repo.ggf.sigma2.export_sigma_second_variation`
   - `your_repo.su4.hessian_path.export_hessian_family`

2) Run the orchestrator:
   ```bash
   cd geodesic_specs_v1
   python orchestrate_final.py
   ```

3) Inspect:
   - `GO_NOGO.txt` should read **GO**.
   - `COMPLETENESS.json` per-claim scores ≈ **1.0** with real data present.
   - `INVARIANT_AUDIT.json` shows invariants present in certificates.
   - `docs/external_invariants/SOURCE_INVARIANTS.json` confirms invariants appear in your source docs.

4) Cut the release:
   ```bash
   python make_release.py
   ```
   This packages dashboard, JUnit, Merkle, witness, checklist, and certs into `dist/…zip`.
