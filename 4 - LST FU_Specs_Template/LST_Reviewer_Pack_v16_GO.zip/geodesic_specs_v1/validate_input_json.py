#!/usr/bin/env python3
import json, argparse, sys

def validate(obj, schema):
    errs = []
    # required keys
    for k in schema.get("required", []):
        if k not in obj:
            errs.append(f"missing required key: {k}")
    # shallow shape checks for arrays
    props = schema.get("properties", {})
    for k,v in props.items():
        if k in obj and v.get("type") == "object":
            pass
        if k in obj and v.get("type") == "array":
            if not isinstance(obj[k], list):
                errs.append(f"{k} not a list")
    return errs

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--schema', required=True)
    ap.add_argument('--data', required=True)
    ap.add_argument('--out', default='INPUT_VALIDATION.json')
    args = ap.parse_args()
    with open(args.schema,'r',encoding='utf-8') as f:
        schema = json.load(f)
    with open(args.data,'r',encoding='utf-8') as f:
        data = json.load(f)
    errs = validate(data, schema)
    out = {"schema": args.schema, "data": args.data, "ok": len(errs)==0, "errors": errs}
    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out))

if __name__ == '__main__':
    main()
