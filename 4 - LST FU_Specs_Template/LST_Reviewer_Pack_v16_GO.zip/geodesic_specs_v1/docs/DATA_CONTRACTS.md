# Data Contracts for Integrations

## Horizon constraints (U(1) selection)
- **Function**: `export_horizon_constraints(**kwargs)`
- **Return**: `list[list[number]]` with shape `(m_rows, n_cycles)`
- **Persisted to**: `inputs/horizon_P3.csv`

## Σ'' baseline (projector uniqueness)
- **Function**: `export_sigma_second_variation(**kwargs)`
- **Return**: square SPD `list[list[number]]` (n×n)
- **Persisted to**: `inputs/sigma_second_variation.csv`

## SU(4) Hessian family (no-go)
- **Function**: `export_hessian_family(**kwargs)`
- **Return**: `list` of matrices (each `list[list[number]]`, n×n)
- **Persisted to**: `inputs/su4_hessian/H_###.csv`
