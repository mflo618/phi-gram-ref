# Integrity & Reproducibility Notes

- All certificates include seeds and SHA-256 hashes for local artifacts.
- `validate_all.py` enforces schema shape; `summarize_certs.py` provides a one-line rollup.
- `red_team.py` demonstrates concrete mutations that SHOULD fail thresholds, ensuring the harness is fail-loud.
- `MANIFEST.json` records the file tree with hashes for provenance.
