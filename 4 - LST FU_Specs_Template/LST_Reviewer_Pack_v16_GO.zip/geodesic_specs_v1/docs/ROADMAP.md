# Roadmap to Sufficient Completeness

- Wire **U(1)** constraints directly from the horizon extractor → expect `abelian_rank=1` against schema.
- Export **Σ″(τ=0)** from GGF module and feed `C_projector_uniqueness/S_baseline.json`.
- Replace SU(4) model Hessians with generated ones from the SU(4) alignment path; maintain negative mode witness.
- Barrier proof: derive margins symbolically, numeric check remains a witness.

Each milestone closes with a schema-validated CERT and a red-team mutation that proves the harness would have caught a regression.
