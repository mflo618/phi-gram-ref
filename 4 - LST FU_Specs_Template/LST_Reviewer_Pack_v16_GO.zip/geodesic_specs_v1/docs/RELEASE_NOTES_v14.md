# Release Notes — v14 Invariants Alignment (UTC: 2025-10-27 15:56:23Z)

- Added `docs/external_invariants/SOURCE_INVARIANTS.json` (extracted from your Markdown + DOCX; PDF hashed).
- Added `docs/external_invariants/CERT_INVARIANTS_ALIGNMENT.json` to confirm cert invariants appear across certificates.
- Wrote `HOWTO_FINALIZE.md` to guide the final physics-backed release procedure.
