# Assurance Case (GSN-Style, Text)

Goal G0: Demonstrate non-empirical/geodesic tensions are resolved to sufficiency.
  Strategy S1: For each claim, provide dual-route reasoning + machine-verifiable certificate.
    Context C1: UTC, GDI, P3/P4, resonance (5,6), fixed invariants (6/5, D_eff, h, κ).

  Goal G1: U(1) selection proven.
    Solution Sn1: SNF + rational-rank agreement; abelian_rank = 1; Σ-Hessian one flat Abelian dir.
    Evidence E1: constraints.json, SNF_REPORT.json, holonomy_metrics.json, CERT_U1_v2.json.

  Goal G2: D_eff uniqueness.
    Solution Sn2: Interval arithmetic enclosure + F'(D)<0 + L=0 contraction; CERT_Deff_v2.json.

  Goal G3: Projector uniqueness.
    Solution Sn3: Projector sweep on Σ″(τ=0), stable C_sigma and identical signatures; CERT_proj_v2.json.

  Goal G4: SU(4) no-go.
    Solution Sn4: Negative mode witness via Sylvester and Gershgorin; minimal witness recorded; CERT_su4_v2.json.

  Goal G5: Singularity preclusion.
    Solution Sn5: Positive margins from energy identity & barrier; CERT_nosing_v2.json.

  Goal G6: System integrity & reproducibility.
    Solution Sn6: Schemas, seeds, Merkle root, CI, GO/NOGO, red-team, dashboard.
