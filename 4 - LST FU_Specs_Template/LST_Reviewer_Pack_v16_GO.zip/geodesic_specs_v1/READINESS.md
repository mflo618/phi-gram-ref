# Readiness Snapshot

GO/NOGO: **UNKNOWN**

Remaining actions to lock physics-backed sufficiency:
1) Feed **horizon constraints** into U(1) harness (`integrations.json` → horizon exporter).
2) Export **Σ″(τ=0)** into projector sweep.
3) Export **SU(4) Hessian family** near τ=0 for Sylvester/minimal witness.
4) Supply **Robin parameters** to compute barrier margins.
5) Re-run `make_release.py` to mint the signed artifact set with Merkle root and JUnit.

Artifacts to share with reviewers:
- `dashboard.html` (visual overview)
- `TEST-certs.xml` (CI/JUnit)
- `MERKLE_ROOT.txt` + `MERKLE_LEAVES.json` (provenance)
- `SUFFICIENCY_CHECKLIST.json` (one-glance checklist)
