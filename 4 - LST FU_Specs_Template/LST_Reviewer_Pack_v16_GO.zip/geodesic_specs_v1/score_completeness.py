#!/usr/bin/env python3
import os, json, argparse

CLAIMS = {
    "C-U1": {
        "data": ["A_U1_selection/constraints.json"],
        "dual": ["A_U1_selection/SNF_REPORT.json", "A_U1_selection/holonomy_rank.json"],
        "red":  ["REDTEAM_REPORT.json"],  # contains U1 mutation
    },
    "C-Dunique": {
        "data": [],
        "dual": ["B_Deff_uniqueness/Deff_interval_proof.json", "B_Deff_uniqueness/Deff_metrics_v2.json"],
        "red":  ["REDTEAM_REPORT.json"],
    },
    "C-Proj": {
        "data": ["C_projector_uniqueness/S_baseline.json"],
        "dual": ["C_projector_uniqueness/proj_metrics_v2.json"],
        "red":  ["REDTEAM_REPORT.json"],
    },
    "C-SU4-NoGo": {
        "data": ["D_su4_no_go/hessian_inputs.json"],
        "dual": ["D_su4_no_go/SYL_cert.json", "D_su4_no_go/GERSH_cert.json", "D_su4_no_go/minimal_witness.json"],
        "red":  ["REDTEAM_REPORT.json"],
    },
    "C-NoSing": {
        "data": [],
        "dual": ["E_no_singularity/nosing_metrics_v2.json"],
        "red":  ["REDTEAM_REPORT.json"],
    }
}

def exists_nonempty(p):
    return os.path.exists(p) and os.path.getsize(p) > 10

def has_red_coverage():
    p = "REDTEAM_REPORT.json"
    if not exists_nonempty(p):
        return False
    try:
        with open(p,'r',encoding='utf-8') as f:
            j = json.load(f)
        # pass means all injected failures were caught
        return bool(j.get("red_team_pass", False))
    except Exception:
        return False

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='COMPLETENESS.json')
    args = ap.parse_args()
    red_ok = has_red_coverage()
    per = {}
    for cid, spec in CLAIMS.items():
        data_ok = all(exists_nonempty(p) for p in spec["data"]) if spec["data"] else True
        dual_ok = all(exists_nonempty(p) for p in spec["dual"])
        red_cov = red_ok  # coarse; single red-team file covers all
        score = 0.4*(1.0 if data_ok else 0.0) + 0.4*(1.0 if dual_ok else 0.0) + 0.2*(1.0 if red_cov else 0.0)
        per[cid] = {
            "data_present": data_ok,
            "dual_witness_present": dual_ok,
            "redteam_covered": red_cov,
            "score": round(score, 3)
        }
    overall = round(sum(x["score"] for x in per.values())/len(per), 3)
    out = {"overall": overall, "claims": per}
    with open(args.out,'w',encoding='utf-8') as f:
        json.dump(out,f,indent=2)
    print(json.dumps(out))
if __name__ == "__main__":
    main()
