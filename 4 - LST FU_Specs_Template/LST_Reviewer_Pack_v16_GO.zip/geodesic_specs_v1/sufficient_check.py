#!/usr/bin/env python3
import os, json, argparse, time, xml.etree.ElementTree as ET

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--summary', default='CERT_summary.csv')
    ap.add_argument('--validation', default='validation_report.json')
    ap.add_argument('--out-xml', default='TEST-certs.xml')
    ap.add_argument('--out-go', default='GO_NOGO.txt')
    args = ap.parse_args()

    # Parse CSV summary
    certs = []
    if os.path.exists(args.summary):
        import csv
        with open(args.summary, 'r', encoding='utf-8') as f:
            for i, row in enumerate(csv.reader(f)):
                if i == 0: 
                    header = row; 
                    continue
                if not row: continue
                certs.append({'claim_id': row[0], 'version': row[1], 'pass': row[2] == 'True', 'reason': row[3], 'path': row[4]})

    # Parse validation JSON
    validation_ok = False
    validation_errors = []
    if os.path.exists(args.validation):
        with open(args.validation, 'r', encoding='utf-8') as f:
            v = json.load(f)
        validation_ok = v.get('ok', False)
        for r in v.get('results', []):
            if r.get('status') == 'fail':
                validation_errors.append({'cert': r.get('cert'), 'errors': r.get('errors', [])})

    # Build JUnit XML
    ts = ET.Element('testsuite', name='LST-Certificates', tests=str(len(certs)+1))
    # Add validation as one testcase
    tc_val = ET.SubElement(ts, 'testcase', name='schema_validation', classname='validation', time='0.0')
    if not validation_ok:
        fail = ET.SubElement(tc_val, 'failure', message='Schema validation failed')
        fail.text = json.dumps(validation_errors, indent=2)
    # Add cert testcases
    for c in certs:
        tc = ET.SubElement(ts, 'testcase', name=c['claim_id'], classname='cert', time='0.0')
        if not c['pass']:
            fail = ET.SubElement(tc, 'failure', message='Certificate did not pass')
            fail.text = c['reason']
    xml = ET.tostring(ts, encoding='unicode')
    with open(args.out_xml, 'w', encoding='utf-8') as f:
        f.write(xml)

    # GO/NOGO gate: all certs pass AND validation ok
    go = (all(c['pass'] for c in certs) and validation_ok)
    with open(args.out_go, 'w', encoding='utf-8') as f:
        f.write('GO\n' if go else 'NOGO\n')
        f.write(f"certs_pass={all(c['pass'] for c in certs)} validation_ok={validation_ok}\n")
    print(json.dumps({'go': go, 'certs': len(certs), 'validation_ok': validation_ok}))

if __name__ == '__main__':
    main()
