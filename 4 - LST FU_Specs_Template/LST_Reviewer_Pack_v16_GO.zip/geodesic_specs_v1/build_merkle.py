#!/usr/bin/env python3
import os, hashlib, json, argparse

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def merkle_root(files):
    # binary Merkle tree; if odd, last leaf is duplicated
    nodes = [bytes.fromhex(h) for h in files]
    if not nodes:
        return None
    while len(nodes) > 1:
        next_level = []
        for i in range(0, len(nodes), 2):
            a = nodes[i]
            b = nodes[i] if i+1==len(nodes) else nodes[i+1]
            h = hashlib.sha256(a + b).digest()
            next_level.append(h)
        nodes = next_level
    return nodes[0].hex()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base', default='.')
    ap.add_argument('--out-root', default='MERKLE_ROOT.txt')
    ap.add_argument('--out-list', default='MERKLE_LEAVES.json')
    args = ap.parse_args()
    # include only certs, reports, schemas, code
    include = []
    for base, _, files in os.walk(args.base):
        for f in files:
            p = os.path.join(base, f)
            if any(f.endswith(ext) for ext in ('.json','.py','.md','.csv','.schema.json','.txt','.ipynb','.xml','.html')):
                include.append(p)
    include = sorted(set(include))
    leaves = [{"path": os.path.relpath(p, args.base), "sha256": sha256(p)} for p in include]
    root_hash = merkle_root([x["sha256"] for x in leaves]) or ""
    with open(args.out_root, 'w', encoding='utf-8') as f:
        f.write(root_hash + "\n")
    with open(args.out_list, 'w', encoding='utf-8') as f:
        json.dump(leaves, f, indent=2)
    print(json.dumps({"root": root_hash, "count": len(leaves)}))

if __name__ == '__main__':
    main()
