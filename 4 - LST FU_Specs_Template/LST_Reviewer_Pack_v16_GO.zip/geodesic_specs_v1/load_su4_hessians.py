#!/usr/bin/env python3
import json, argparse, csv, os, glob

def read_matrix_csv(p):
    A=[]
    with open(p, 'r', encoding='utf-8') as f:
        for row in csv.reader(f):
            if not row: continue
            A.append([float(x) for x in row])
    return A

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--folder', default='inputs/su4_hessian/', help='Folder with CSV Hessian matrices')
    ap.add_argument('--out', default='D_su4_no_go/hessian_inputs.json')
    args = ap.parse_args()
    if not os.path.isdir(args.folder):
        print(json.dumps({"status":"noop","reason":"no hessian folder"})); return
    hs = []
    for p in sorted(glob.glob(os.path.join(args.folder, "*.csv"))):
        hs.append({"path": os.path.basename(p), "H": read_matrix_csv(p)})
    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump({"hessians": hs}, f, indent=2)
    print(json.dumps({"status":"ok","count":len(hs)}))

if __name__ == "__main__":
    main()
