# Validator + Summary (v3)

Run from `geodesic_specs_v1/`:

```
python summarize_certs.py
python validate_all.py \
  --schemas A_U1_selection/CERT_U1.schema.json \
           B_Deff_uniqueness/CERT_Deff.schema.json \
           C_projector_uniqueness/CERT_proj.schema.json \
           D_su4_no_go/CERT_su4.schema.json \
           E_no_singularity/CERT_nosing.schema.json \
  --certs A_U1_selection/CERT_U1_v2.json \
          B_Deff_uniqueness/CERT_Deff_v2.json \
          C_projector_uniqueness/CERT_proj_v2.json \
          D_su4_no_go/CERT_su4_v2.json \
          E_no_singularity/CERT_nosing_v2.json

cat validation_report.json
```
