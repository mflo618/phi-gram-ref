#!/usr/bin/env python3
import os, subprocess, sys, json, csv

def run(cmd, cwd):
    try:
        out = subprocess.check_output(cmd, cwd=cwd, stderr=subprocess.STDOUT, text=True)
        return True, out.strip()
    except subprocess.CalledProcessError as e:
        return False, e.output

def main():
    base = os.path.dirname(__file__) or "."
    report = []
    # Integrations (try real exporters; fall back to demo inputs)
    ok0, out0 = run(["python", "use_integrations.py", "--demo-if-missing"], base)
    report.append({"step":"integrations","cmd":"python use_integrations.py --demo-if-missing","ok": ok0, "out": out0})
    # Adapters (optional)
    adapters = [
        ["python", "gen_constraints_from_horizon.py"],
        ["python", "load_sigma2_baseline.py"],
        ["python", "load_su4_hessians.py"],
    ]
    for cmd in adapters:
        ok, out = run(cmd, base)
        report.append({"step":"adapter","cmd":" ".join(cmd), "ok": ok, "out": out})
    # Core v2 checks
    # Validate inputs (JSON shape)
    run(["python","validate_input_json.py","--schema","schemas/horizon_constraints.schema.json","--data","A_U1_selection/constraints.json","--out","A_U1_selection/INPUT_VALIDATION.json"], base)
    run(["python","validate_input_json.py","--schema","schemas/sigma2.schema.json","--data","C_projector_uniqueness/S_baseline.json","--out","C_projector_uniqueness/INPUT_VALIDATION.json"], base)
    run(["python","validate_input_json.py","--schema","schemas/hessian_family.schema.json","--data","D_su4_no_go/hessian_inputs.json","--out","D_su4_no_go/INPUT_VALIDATION.json"], base)

    checks = [
        ["python", "B_Deff_uniqueness/fixed_point_bounds_v2.py"],
        ["python", "A_U1_selection/abelian_rank_snf.py"],
        ["python", "C_projector_uniqueness/projector_sweep_v2.py"],
        ["python", "D_su4_no_go/hessian_multi_v2.py"],
        ["python", "E_no_singularity/check_barrier_v2.py"],
    ]
    for cmd in checks:
        ok, out = run(cmd, base)
        report.append({"step":"check","cmd":" ".join(cmd), "ok": ok, "out": out})
    # Interval Deff proof and Sylvester certificate
    okI, outI = run(["python", "B_Deff_uniqueness/interval_proof.py"], base)
    report.append({"step":"interval_Deff","cmd":"python B_Deff_uniqueness/interval_proof.py","ok": okI, "out": outI})
    okS, outS = run(["python", "D_su4_no_go/sylvester_certificate.py"], base)
    report.append({"step":"sylvester_su4","cmd":"python D_su4_no_go/sylvester_certificate.py","ok": okS, "out": outS})
    # phi-gram external witness (optional)
    okPG, outPG = run(["python", "external/run_phi_gram.py", "--group", "su4", "--grid", "14", "--B", "512", "--refine", "1"], base)
    report.append({"step":"phi_gram_run","cmd":"python external/run_phi_gram.py --group su4 --grid 14 --B 512 --refine 1","ok": okPG, "out": outPG})
    okPC, outPC = run(["python", "external/make_phi_cert.py"], base)
    report.append({"step":"phi_gram_cert","cmd":"python external/make_phi_cert.py","ok": okPC, "out": outPC})
    # Summarize
    ok1, out1 = run(["python", "summarize_certs.py"], base)
    report.append({"step":"summary","cmd":"python summarize_certs.py","ok": ok1, "out": out1})
    # Validate (schemas expected in place)
    ok2, out2 = run(["python","validate_all.py",
                     "--schemas",
                     "A_U1_selection/CERT_C.schema.json",
                     "B_Deff_uniqueness/CERT_C.schema.json",
                     "C_projector_uniqueness/CERT_C.schema.json",
                     "D_su4_no_go/CERT_C.schema.json",
                     "E_no_singularity/CERT_C.schema.json",
                     "external/CERT_PhiGram.schema.json",
                     "--certs",
                     "A_U1_selection/CERT_U1_v2.json",
                     "B_Deff_uniqueness/CERT_Deff_v2.json",
                     "C_projector_uniqueness/CERT_proj_v2.json",
                     "D_su4_no_go/CERT_su4_v2.json",
                     "E_no_singularity/CERT_nosing_v2.json", \
          "external/CERT_phigram_v2.json"], base)
    report.append({"step":"validate","cmd":"python validate_all.py ...","ok": ok2, "out": out2})
    # Write report
    with open(os.path.join(base, "RUN_REPORT.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(json.dumps({"done": True, "steps": len(report)}))

if __name__ == "__main__":
    main()
