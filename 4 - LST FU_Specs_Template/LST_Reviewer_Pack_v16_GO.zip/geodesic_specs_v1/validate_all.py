#!/usr/bin/env python3
import json, argparse, os, sys

def load_json(p):
    with open(p, 'r', encoding='utf-8') as f:
        return json.load(f)

def soft_validate(schema, cert):
    errors = []
    # Required top-level
    required = schema.get('required', [])
    for k in required:
        if k not in cert:
            errors.append(f"missing required field: {k}")
    # Metrics
    metrics_spec = schema.get('properties', {}).get('metrics', {})
    need_metrics = list(metrics_spec.get('properties', {}).keys())
    for m in need_metrics:
        if 'metrics' in cert and m not in cert['metrics']:
            errors.append(f"missing metrics['{m}']")
    # Claim id const
    claim_spec = schema.get('properties', {}).get('claim_id', {})
    const_val = claim_spec.get('const')
    if const_val is not None and cert.get('claim_id') != const_val:
        errors.append(f"claim_id mismatch (expected {const_val}, got {cert.get('claim_id')})")
    return errors

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--schemas', nargs='+', required=True, help='List of schema files')
    ap.add_argument('--certs', nargs='+', required=True, help='List of cert files')
    ap.add_argument('--out', default='validation_report.json')
    args = ap.parse_args()
    # map schemas by claim_id
    schema_by_claim = {}
    for sp in args.schemas:
        sch = load_json(sp)
        # Try to infer claim id
        claim_id = sch.get('properties', {}).get('claim_id', {}).get('const', None)
        if not claim_id:
            # fallback: parse from filename
            claim_id = os.path.basename(sp).split('.')[0].split('_')[1] if '_' in os.path.basename(sp) else os.path.basename(sp)
        schema_by_claim[claim_id] = {'path': sp, 'schema': sch}
    results = []
    ok = True
    for cp in args.certs:
        cert = load_json(cp)
        cid = cert.get('claim_id')
        sch = schema_by_claim.get(cid)
        if not sch:
            results.append({'cert': cp, 'status': 'warn', 'errors': [f'no schema found for claim_id={cid}']})
            continue
        errs = soft_validate(sch['schema'], cert)
        status = 'ok' if not errs else 'fail'
        if errs: ok = False
        results.append({'cert': cp, 'schema': sch['path'], 'status': status, 'errors': errs})
    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump({'ok': ok, 'results': results}, f, indent=2)
    print(json.dumps({'ok': ok, 'num': len(results), 'fails': sum(1 for r in results if r.get('status')=='fail') }))

if __name__ == '__main__':
    main()
