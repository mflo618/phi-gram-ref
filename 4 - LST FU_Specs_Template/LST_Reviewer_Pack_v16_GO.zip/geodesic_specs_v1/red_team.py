#!/usr/bin/env python3
import json, os, random, math

def snf_free_rank(num_cycles, rank_constraints):
    return max(num_cycles - rank_constraints, 0)

def u1_mutation():
    # create a constraints scenario with abelian_rank = 2 (should FAIL expected rank=1)
    num_cycles = 12
    rank_constraints = 10
    free_rank = snf_free_rank(num_cycles, rank_constraints)
    return {"test":"U1_rank>1", "expected":"fail", "observed_free_rank": free_rank, "pass": (free_rank==1)}

def deff_mutation():
    # mutate the loopback constant slightly and compute Deff tilde
    PHI = (1+5**0.5)/2.0
    base = math.sqrt(6.0/5.0)
    mutated = base*(1+1e-3)
    Deff_true = 3.0 - math.log(base, PHI)
    Deff_mut = 3.0 - math.log(mutated, PHI)
    return {"test":"Deff_constant_perturb", "expected":"fail_if_used", "delta_Deff": Deff_mut - Deff_true, "pass": False}

def proj_mutation():
    # Inflate variance beyond std_max via a contrived spread
    Cs = [1.0 - 0.05, 1.0 + 0.05, 1.0 - 0.04, 1.0 + 0.04]
    mu = sum(Cs)/len(Cs)
    std = (sum((c-mu)**2 for c in Cs)/len(Cs))**0.5
    return {"test":"Proj_variance_inflated", "expected":"fail_if_used", "std": std, "pass": (std <= 0.01)}

def su4_mutation():
    # Construct SPD spectrum only: no negative mode
    eigs = [0.001, 0.002, 0.003]
    min_eig = min(eigs)
    return {"test":"SU4_no_negative_mode", "expected":"fail", "min_eigenvalue": min_eig, "pass": (min_eig < -1e-6)}

def nosing_mutation():
    # Set alpha_H = 0 -> margins 0 (should fail thresholds >0)
    energy_margin = 0.0
    trap_margin = 0.0
    ok = (energy_margin>1e-5 and trap_margin>1e-5)
    return {"test":"NoSing_zero_alphaH", "expected":"fail", "margins": {"energy": energy_margin, "trap": trap_margin}, "pass": ok}

def main():
    tests = [u1_mutation(), deff_mutation(), proj_mutation(), su4_mutation(), nosing_mutation()]
    # pass==True here means pipeline WOULD incorrectly accept; we want all to be False
    # So red-team PASS means all entries have pass==False
    all_ok = all(not t["pass"] for t in tests)
    report = {"red_team_pass": all_ok, "tests": tests}
    print(json.dumps(report, indent=2))
    with open("REDTEAM_REPORT.json","w",encoding="utf-8") as f:
        json.dump(report, f, indent=2)

if __name__ == "__main__":
    main()
