# Pipeline Status

- run_all: OK
- sufficient_check: FAIL
- dashboard: OK

Outputs:
- TEST-certs.xml
- GO_NOGO.txt
- dashboard.html
- CERT_summary.csv
- validation_report.json
