#!/usr/bin/env python3
import os, json, argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--old', default='SNAPSHOT_prev.json')
    ap.add_argument('--new', default='SNAPSHOT.json')
    ap.add_argument('--out', default='DELTA_REPORT.json')
    args = ap.parse_args()
    try:
        with open(args.old,'r',encoding='utf-8') as f: a = json.load(f)
    except Exception: a = {"files":{}}
    with open(args.new,'r',encoding='utf-8') as f: b = json.load(f)
    added = sorted(set(b["files"].keys()) - set(a["files"].keys()))
    removed = sorted(set(a["files"].keys()) - set(b["files"].keys()))
    changed = []
    for k in set(a["files"].keys()) & set(b["files"].keys()):
        if a["files"][k].get("size") != b["files"][k].get("size"):
            changed.append(k)
    out = {"added": added, "removed": removed, "changed": changed}
    with open(args.out,'w',encoding='utf-8') as f:
        json.dump(out,f,indent=2)
    print(json.dumps(out))
if __name__ == "__main__":
    main()
