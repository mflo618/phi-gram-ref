#!/usr/bin/env python3
import os, json, csv, argparse, datetime

def row(cells):
    return "<tr>" + "".join(f"<td>{c}</td>" for c in cells) + "</tr>"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--summary', default='CERT_summary.csv')
    ap.add_argument('--validation', default='validation_report.json')
    ap.add_argument('--go', default='GO_NOGO.txt')
    ap.add_argument('--out', default='dashboard.html')
    args = ap.parse_args()

    certs = []
    if os.path.exists(args.summary):
        with open(args.summary, 'r', encoding='utf-8') as f:
            for i, r in enumerate(csv.reader(f)):
                if i==0: header = r; continue
                if not r: continue
                certs.append(r)
    val_ok = False
    val_detail = ""
    if os.path.exists(args.validation):
        with open(args.validation, 'r', encoding='utf-8') as f:
            v = json.load(f)
        val_ok = v.get('ok', False)
        val_detail = json.dumps(v.get('results', []), indent=2)
    go_text = "UNKNOWN"
    if os.path.exists(args.go):
        with open(args.go, 'r', encoding='utf-8') as f:
            go_text = f.readline().strip()

    html = []
    html.append("<!doctype html><html><head><meta charset='utf-8'><title>LST Certificates Dashboard</title>")
    html.append("<style>body{font-family:system-ui,Segoe UI,Arial,sans-serif;margin:24px} .ok{color:green} .fail{color:#b22222} table{border-collapse:collapse;width:100%} td,th{border:1px solid #ddd;padding:8px} th{background:#f7f7f7;text-align:left}</style></head><body>")
    html.append(f"<h1>LST Certificates Dashboard</h1><p>Generated: {datetime.datetime.utcnow().isoformat()}Z</p>")
    html.append(f"<h2>GO / NOGO: <span class='{('ok' if go_text=='GO' else 'fail')}'>{go_text}</span></h2>")
    html.append(f"<h3>Schema validation: <span class='{('ok' if val_ok else 'fail')}'>{'OK' if val_ok else 'FAILED'}</span></h3>")

    if certs:
        html.append("<h3>Certificates</h3><table><tr><th>Claim</th><th>Version</th><th>Pass</th><th>Reason</th><th>Path</th></tr>")
        for c in certs:
            cls = "ok" if c[2]=="True" else "fail"
            html.append("<tr>")
            html.append(f"<td>{c[0]}</td><td>{c[1]}</td><td class='{cls}'>{c[2]}</td><td>{c[3]}</td><td><code>{c[4]}</code></td>")
            html.append("</tr>")
        html.append("</table>")
    if not val_ok:
        html.append("<h3>Validation Details</h3>")
        html.append("<pre>"+val_detail+"</pre>")
    html.append("</body></html>")
    with open(args.out, 'w', encoding='utf-8') as f:
        f.write("".join(html))
    print(json.dumps({'dashboard': args.out, 'go': go_text, 'validation_ok': val_ok}))

if __name__ == '__main__':
    main()
