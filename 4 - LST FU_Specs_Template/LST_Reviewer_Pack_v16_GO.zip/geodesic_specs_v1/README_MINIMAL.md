# LST — Reviewer Pack (one click)

Two choices:

**A) No compute — just inspect**
- Open `dashboard.html`
- or run: `python verify.py`  (prints pass/fail + GO/NOGO)

**B) Reproduce GO in one command**
