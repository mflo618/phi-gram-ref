#!/usr/bin/env python3
import json, argparse, csv, os

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--horizon', default='inputs/horizon_P3.csv')
    ap.add_argument('--out-json', default='A_U1_selection/constraints.json')
    args = ap.parse_args()
    if not os.path.exists(args.horizon):
        print(json.dumps({"status":"noop","reason":"no horizon file"})); return
    M = []
    with open(args.horizon, 'r', encoding='utf-8') as f:
        for row in csv.reader(f):
            if not row: continue
            M.append([int(round(float(x))) for x in row])
    num_cycles = len(M[0]) if M else 0
    out = {"num_cycles": num_cycles, "M": M}
    with open(args.out_json, 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=2)
    print(json.dumps({"status":"ok","num_cycles":num_cycles,"rows":len(M)}))

if __name__ == "__main__":
    main()
