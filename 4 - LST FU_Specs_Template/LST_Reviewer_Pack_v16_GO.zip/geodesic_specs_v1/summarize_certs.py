#!/usr/bin/env python3
import os, json, csv, argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--glob', default='**/CERT*_v2.json')
    ap.add_argument('--out', default='CERT_summary.csv')
    args = ap.parse_args()
    paths = []
    for base,_,files in os.walk('.'):
        for f in files:
            if f.startswith('CERT') and f.endswith('_v2.json'):
                paths.append(os.path.join(base, f))
    rows=[['claim_id','version','pass','reason','path']]
    for p in sorted(paths):
        with open(p, 'r', encoding='utf-8') as fh:
            j = json.load(fh)
        rows.append([j.get('claim_id'), j.get('version'), j.get('result',{}).get('pass'), j.get('result',{}).get('reason'), p])
    with open(args.out,'w',newline='') as f:
        csv.writer(f).writerows(rows)
    print("wrote", args.out, "with", len(rows)-1, "entries")
if __name__=='__main__':
    main()
