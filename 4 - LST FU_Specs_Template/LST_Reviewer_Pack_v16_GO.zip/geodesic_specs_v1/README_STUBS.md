This directory holds runnable stubs and sample certificates for the Non‑Empirical Geodesic Spec Pack v1.
See the previously provided Spec Pack for detailed specs and schemas.
