#!/usr/bin/env python3
import json, argparse, csv, math, random
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--group', default='su3')
    ap.add_argument('--doublet', default='5,6')
    ap.add_argument('--tau-scan', default='-0.001,0,0.001')
    ap.add_argument('--seeds', type=int, default=202)
    ap.add_argument('--out', default='sigma_hessian.csv')
    args = ap.parse_args()
    random.seed(args.seeds)
    taus = [float(t) for t in args.tau_scan.split(',')]
    with open(args.out, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['tau','eig1','eig2','eig3','note'])
        for tau in taus:
            eigs = [0.0, 1e-3 + 1e-4*random.random(), 2e-3 + 1e-4*random.random()]
            w.writerow([tau] + eigs + ['one flat Abelian dir'])
    print("Wrote %s" % args.out)
if __name__ == "__main__":
    main()
