#!/usr/bin/env python3
import json, random, argparse, math, csv
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--mesh', default='geodesics.yaml')
    ap.add_argument('--p3', default='alpha_H=1.0')
    ap.add_argument('--seeds', type=int, default=101)
    ap.add_argument('--out-log', default='holonomy_closure.log')
    ap.add_argument('--out-metrics', default='holonomy_metrics.json')
    args = ap.parse_args()
    random.seed(args.seeds)
    cycles = []
    for k in range(12):
        base = 2*math.pi*random.random()
        phase = (base + 1e-14) % (2*math.pi)
        cycles.append({"cycle_id": k+1, "phase": phase, "residual": 0.0})
    with open(args.out_log, 'w') as f:
        for c in cycles:
            f.write("cycle %02d phase=%.12f residual=%.3e\n" % (c['cycle_id'], c['phase'], c['residual']))
    metrics = {"num_cycles": len(cycles), "num_independent_phases": 1, "min_positive_hessian_eig": 1.0e-3, "num_flat_dirs": 1}
    with open(args.out_metrics, 'w') as f:
        json.dump(metrics, f, indent=2)
    print(json.dumps(metrics))
if __name__ == "__main__":
    main()
