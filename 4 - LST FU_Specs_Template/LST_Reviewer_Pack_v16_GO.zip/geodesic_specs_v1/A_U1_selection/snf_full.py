#!/usr/bin/env python3
import argparse, json
from math import gcd

def mat_copy(M): return [row[:] for row in M]

def swap_rows(A,i,j): 
    if i!=j: A[i],A[j]=A[j],A[i]

def swap_cols(A,i,j):
    if i!=j:
        for r in range(len(A)): A[r][i],A[r][j]=A[r][j],A[r][i]

def add_rows(A,i,j,k):
    # A[j] += k*A[i]
    A[j] = [a + k*b for a,b in zip(A[i],A[j])]

def add_cols(A,i,j,k):
    for r in range(len(A)):
        A[r][j] += k*A[r][i]

def snf(M):
    # Compute Smith Normal Form D ~ U M V (U,V unimodular) for small integer M. Returns D, rank.
    A = mat_copy(M)
    m = len(A); n = len(A[0]) if m else 0
    i = j = 0
    while i<m and j<n:
        # find nonzero pivot with smallest |entry|
        pi=pj=None; val=None
        for r in range(i,m):
            for c in range(j,n):
                if A[r][c]!=0:
                    if val is None or abs(A[r][c])<val:
                        val = abs(A[r][c]); pi, pj = r, c
        if val is None: break
        swap_rows(A,i,pi); swap_cols(A,j,pj)
        # make other entries in row/col divisible by pivot using Euclid
        while True:
            changed=False
            # clear other rows in column j
            for r2 in range(m):
                if r2==i: continue
                if A[r2][j]!=0:
                    q = A[r2][j] // A[i][j]
                    add_rows(A,i,r2,-q)
                    if abs(A[r2][j])>=abs(A[i][j]):
                        # Euclid swap
                        A[i],A[r2]=A[r2],A[i]
                        changed=True; break
            if changed: continue
            # clear other cols in row i
            for c2 in range(n):
                if c2==j: continue
                if A[i][c2]!=0:
                    q = A[i][c2] // A[i][j]
                    add_cols(A,j,c2,-q)
                    if abs(A[i][c2])>=abs(A[i][j]):
                        # Euclid swap columns
                        for rr in range(m): A[rr][j],A[rr][c2]=A[rr][c2],A[rr][j]
                        changed=True; break
            if not changed: break
        if A[i][j]<0: A[i][j] = -A[i][j]
        # reduce other entries modulo pivot
        for r2 in range(m):
            if r2!=i and A[r2][j]!=0:
                q = A[r2][j] // A[i][j]
                add_rows(A,i,r2,-q)
        for c2 in range(n):
            if c2!=j and A[i][c2]!=0:
                q = A[i][c2] // A[i][j]
                add_cols(A,j,c2,-q)
        i+=1; j+=1
    # Rank estimation: count nonzero rows (conservative). For small M this is fine.
    rank = 0
    for r in range(len(A)):
        if any(x!=0 for x in A[r]): rank += 1
    return A, rank

def rank_rational(M):
    from fractions import Fraction
    A = [[Fraction(x,1) for x in row] for row in M]
    m = len(A); n = len(A[0]) if m else 0
    r = c = 0
    while r<m and c<n:
        piv = None
        for i in range(r,m):
            if A[i][c] != 0:
                piv = i; break
        if piv is None:
            c += 1; continue
        if piv != r: A[r],A[piv] = A[piv],A[r]
        p = A[r][c]
        A[r] = [x/p for x in A[r]]
        for i in range(m):
            if i==r: continue
            if A[i][c] != 0:
                fac = A[i][c]
                A[i] = [x - fac*y for x,y in zip(A[i],A[r])]
        r += 1; c += 1
    rank = 0
    for i in range(m):
        if any(A[i][j] != 0 for j in range(n)):
            rank += 1
    return rank

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--constraints', default='A_U1_selection/constraints.json')
    ap.add_argument('--out', default='A_U1_selection/SNF_REPORT.json')
    args = ap.parse_args()
    with open(args.constraints,'r',encoding='utf-8') as f:
        data = json.load(f)
    M = data['M']; num_cycles = data['num_cycles']
    D, r1 = snf(M)
    r2 = rank_rational(M)
    free_rank_1 = max(num_cycles - r1, 0)
    free_rank_2 = max(num_cycles - r2, 0)
    rep = {
        "snf_rank": r1, "rational_rank": r2,
        "abelian_rank_snf": free_rank_1, "abelian_rank_q": free_rank_2,
        "agree": (r1 == r2 and free_rank_1 == free_rank_2),
        "D_diagonal": D
    }
    with open(args.out,'w',encoding='utf-8') as f:
        json.dump(rep,f,indent=2)
    print(json.dumps(rep))
if __name__ == "__main__":
    main()
