#!/usr/bin/env python3
# Compute the rank of the surviving Abelian factor (U(1)^r) given integer constraints via Smith Normal Form.
import argparse, json

def snf(M):
    # Basic Smith Normal Form for small integer matrices (not optimized)
    from math import gcd
    M = [row[:] for row in M]
    m, n = len(M), len(M[0]) if M else 0
    i = j = 0
    while i < m and j < n:
        # Find pivot
        pivot = None
        for r in range(i, m):
            for c in range(j, n):
                if M[r][c] != 0:
                    pivot = (r, c); break
            if pivot: break
        if not pivot: break
        r, c = pivot
        # Swap rows/cols
        M[i], M[r] = M[r], M[i]
        for row in M: row[j], row[c] = row[c], row[j]
        # Clear other entries in row/col using gcd-based operations
        while True:
            # Clear below
            progressed = False
            for r2 in range(i+1, m):
                if M[r2][j] != 0:
                    q = M[r2][j] // M[i][j]
                    M[r2] = [a - q*b for a,b in zip(M[r2], M[i])]
                    progressed = True
            # Clear right
            for c2 in range(j+1, n):
                if M[i][c2] != 0:
                    q = M[i][c2] // M[i][j]
                    for rr in range(m):
                        M[rr][c2] = M[rr][c2] - q*M[rr][j]
                    progressed = True
            if not progressed:
                # Try to reduce the pivot via gcd with any remaining entries
                reduced = False
                for r2 in range(i+1, m):
                    g = gcd(abs(M[i][j]), abs(M[r2][j]))
                    if g != abs(M[i][j]) and g != 0:
                        for c2 in range(n):
                            M[i][c2], M[r2][c2] = M[r2][c2], M[i][c2]
                        reduced = True; break
                if not reduced:
                    for c2 in range(j+1, n):
                        g = gcd(abs(M[i][j]), abs(M[i][c2]))
                        if g != abs(M[i][j]) and g != 0:
                            for rr in range(m):
                                M[rr][j], M[rr][c2] = M[rr][c2], M[rr][j]
                            reduced = True; break
                if not reduced:
                    break
        i += 1; j += 1
    # Rank is number of nonzero diagonal entries after reduction when matrix is near-diagonal
    # For small matrices this heuristic works sufficiently; otherwise fall back to numeric rank over Q
    rank = 0
    for r in range(min(m,n)):
        if any(abs(M[r][c])>0 for c in range(n)):
            # approximate: count row nonzero => contribute to rank
            if any(M[r][c]!=0 for c in range(n)): rank += 1
    return M, rank

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--constraints', default='constraints.json', help='JSON with integer matrix of constraints')
    ap.add_argument('--out', default='holonomy_rank.json')
    args = ap.parse_args()
    with open(args.constraints, 'r') as f:
        data = json.load(f)
    M = data.get("M", [])
    cycles = int(data.get("num_cycles", 0))
    _, rank_constraints = snf(M)
    free_rank = max(cycles - rank_constraints, 0)
    # We interpret free_rank as the number of independent U(1) angles (Abelian factor rank)
    out = {"num_cycles": cycles, "rank_constraints": rank_constraints, "abelian_rank": free_rank}
    with open(args.out, 'w') as f:
        json.dump(out, f, indent=2)
    print(json.dumps(out))
if __name__ == "__main__":
    main()
