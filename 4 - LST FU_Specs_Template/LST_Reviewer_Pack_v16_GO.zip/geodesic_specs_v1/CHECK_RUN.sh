#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python orchestrate_final.py
python make_release.py
echo "Done. See dist/ for the release zip and dashboard.html for the summary."
