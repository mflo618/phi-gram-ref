#!/usr/bin/env python3
import argparse, subprocess, sys, json, os

def run(cmd, cwd):
    try:
        out = subprocess.check_output(cmd, cwd=cwd, stderr=subprocess.STDOUT, text=True)
        return True, out.strip()
    except subprocess.CalledProcessError as e:
        return False, e.output

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('claim', choices=['U1','Deff','Proj','SU4','NoSing','ALL'])
    args = ap.parse_args()
    base = os.path.dirname(__file__) or "."
    cmds = {
        "U1": [["python","A_U1_selection/snf_full.py"],["python","A_U1_selection/abelian_rank_snf.py"]],
        "Deff": [["python","B_Deff_uniqueness/interval_proof.py"],["python","B_Deff_uniqueness/fixed_point_bounds_v2.py"]],
        "Proj": [["python","C_projector_uniqueness/projector_sweep_v2.py"]],
        "SU4": [["python","D_su4_no_go/sylvester_certificate.py"],["python","D_su4_no_go/gershgorin_certificate.py"],["python","D_su4_no_go/witness_minimizer.py"]],
        "NoSing": [["python","E_no_singularity/check_barrier_v2.py"]],
    }
    if args.claim == "ALL":
        seq = sum(cmds.values(), [])
    else:
        seq = cmds[args.claim]
    rep=[]
    for cmd in seq:
        ok, out = run(cmd, base); rep.append({"cmd":" ".join(cmd), "ok": ok, "out": out})
    print(json.dumps({"ran": len(rep), "results": rep}, indent=2))

if __name__ == "__main__":
    main()
