#!/usr/bin/env python3
import os, json, subprocess, sys, zipfile, datetime

def run(cmd, cwd):
    try:
        out = subprocess.check_output(cmd, cwd=cwd, stderr=subprocess.STDOUT, text=True)
        return True, out.strip()
    except subprocess.CalledProcessError as e:
        return False, e.output

def main():
    base = os.path.dirname(__file__) or "."
    # Full pipeline
    steps = []
    for cmd in [
        ["python","run_all.py"],
        ["python","sufficient_check.py"],
        ["python","generate_dashboard.py"],
        ["python","build_merkle.py"],
        ["python","D_su4_no_go/witness_minimizer.py"],
        ["python","build_checklist.py"]
    ]:
        ok, out = run(cmd, base); steps.append((cmd, ok, out))
        if not ok: print(out)
    # Collect artifacts
    artifacts = [
        "CERT_summary.csv","validation_report.json","GO_NOGO.txt","TEST-certs.xml","dashboard.html",
        "MERKLE_ROOT.txt","MERKLE_LEAVES.json","D_su4_no_go/minimal_witness.json","SUFFICIENCY_CHECKLIST.json",
        "RUN_REPORT.json","RUN_STATUS.md"
    ]
    ts = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    dist = os.path.join(base, "dist"); os.makedirs(dist, exist_ok=True)
    zpath = os.path.join(dist, f"LST_NonEmpirical_Release_{ts}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for a in artifacts:
            p = os.path.join(base, a)
            if os.path.exists(p):
                z.write(p, arcname=a)
    print(json.dumps({"release_zip": zpath}))

if __name__ == "__main__":
    main()
