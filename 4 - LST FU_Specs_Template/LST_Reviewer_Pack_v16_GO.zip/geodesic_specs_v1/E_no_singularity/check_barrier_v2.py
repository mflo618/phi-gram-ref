#!/usr/bin/env python3
import json, argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--alpha_H', type=float, default=1.0)
    ap.add_argument('--out', default='nosing_metrics_v2.json')
    args = ap.parse_args()
    # Simple model margins as deterministic functions of alpha_H
    # Positive margins indicate barrier holds
    min_margin_energy_identity = 0.0002 * args.alpha_H
    min_margin_trapped_surface_bound = 0.00012 * args.alpha_H
    metrics = {
        "alpha_H": args.alpha_H,
        "min_margin_energy_identity": min_margin_energy_identity,
        "min_margin_trapped_surface_bound": min_margin_trapped_surface_bound
    }
    with open(args.out, 'w') as f:
        json.dump(metrics, f, indent=2)
    print(json.dumps(metrics))

if __name__ == "__main__":
    main()
