# your_repo/ggf/sigma2.py
# Exporter stub that returns Σ''(τ=0) as a square SPD matrix baseline for curvature.
def export_sigma_second_variation(n: int = 3):
    # Simple SPD baseline
    if n == 3:
        return [[2.0, 0.3, 0.1],
                [0.3, 1.6, 0.2],
                [0.1, 0.2, 1.25]]
    # generic SPD: diagonal dominance
    A = [[0.0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            A[i][j] = 0.1 if i!=j else 1.0 + 0.2*i
    return A
