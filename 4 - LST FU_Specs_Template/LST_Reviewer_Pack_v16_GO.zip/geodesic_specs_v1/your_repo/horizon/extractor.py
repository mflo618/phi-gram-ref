# your_repo/horizon/extractor.py
# Exporter stub that returns horizon P3 constraints matrix (m x n) for holonomy SNF.
# Each row is an integer constraint; columns correspond to cycles.
def export_horizon_constraints(num_cycles: int = 12, constraints: int = 11):
    M = [[1 if c==r else 0 for c in range(num_cycles)] for r in range(constraints)]
    return M
