# your_repo/su4/hessian_path.py
# Exporter stub that returns a family of Hessians along an SU(4) alignment path near τ=0.
# At least one member has exactly one negative mode (witnessing the no-go condition).
def export_hessian_family(k: int = 5):
    fam = []
    for i in range(k):
        # Diagonal form as a conservative witness: one negative, two positive
        neg = -1.0e-4 - 2.0e-5*i
        fam.append([[neg, 0.0, 0.0],
                    [0.0, 1.0e-3 + 1.0e-4*i, 0.0],
                    [0.0, 0.0, 2.0e-3 + 1.0e-4*i]])
    return fam
