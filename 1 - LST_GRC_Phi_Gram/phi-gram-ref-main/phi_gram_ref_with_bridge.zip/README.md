# phi_gram_ref (with Bridge)

End-to-end validation script for the geometric filter and the one-loop bridge (SU(3) calibration → SU(4) prediction).

## Quickstart
```bash
python phi_gram_ref.py --cesaro-start-T --check-dynamics --group both
```

## Full validation with bridge
```bash
python phi_gram_ref.py --cesaro-start-T --check-dynamics --group both --bridge --R0_SU3 1.152 --R0_SU4 1.20
# Robust aggregation over the top-K:
python phi_gram_ref.py --cesaro-start-T --check-dynamics --group both --bridge --bridge-agg median_topk
```

## Helpful flags
- `--no-color` : disable emoji/colors in CLI
- `--objective relmin|det|minnorm` : unified scan objective (default: relmin)
- `--report-topk K` : include top-K points by the objective in summary JSON
- `--check-b-doubling` : recompute best point at 2B for stability
- `--refine N --refine-grid G --refine-radius R` : local refinements
- `--Nproj` : Cesàro steps; `--B` : boundary resolution

## Outputs
- `scan_su3.json`, `scan_su4.json`
- `phi_gram_summary.json` (includes `"bridge"` block when `--bridge` is enabled)
